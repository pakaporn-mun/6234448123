/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package lab2.pkg1;

import java.awt.Rectangle;
/**
 *
 * @author Administrator
 */
public class Lab21 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        java.util.Random x = new java.util.Random();
        java.util.Random y = new java.util.Random();
        java.util.Random width = new java.util.Random();
        java.util.Random height = new java.util.Random();
        Rectangle r1 = new Rectangle(x.nextInt(51),y.nextInt(51),width.nextInt(51),height.nextInt(51));
        Rectangle r2 = new Rectangle(x.nextInt(51),y.nextInt(51),width.nextInt(51),height.nextInt(51));
        System.out.println(r1);
        System.out.println(r2);
        Rectangle r3 = r1.intersection(r2);
        boolean empty = r3.isEmpty();
        System.out.println("Is the intersected rectangle empty?"+(empty));
    }

}
