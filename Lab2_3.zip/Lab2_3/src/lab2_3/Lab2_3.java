/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package lab2_3;

import java.util.Calendar;
import java.util.GregorianCalendar;

/**
 *
 * @author Administrator
 */
public class Lab2_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        GregorianCalendar today = new GregorianCalendar(2019,Calendar.JANUARY,8);
        GregorianCalendar birthday = new GregorianCalendar(1990,Calendar.MARCH,12);
        today.add(Calendar.DAY_OF_MONTH,100);
        birthday.add(Calendar.DAY_OF_MONTH,1000);
        
        int weekdayToday = today.get(Calendar.DAY_OF_WEEK);
        String weekdayTODAY =  String.valueOf(weekdayToday);
        int dayToday = today.get(Calendar.DAY_OF_MONTH);
        String dayTODAY =  String.valueOf(dayToday);
        int monthToday = today.get(Calendar.MONTH);
        String monthTODAY = String.valueOf(monthToday);
        int yearToday = today.get(Calendar.YEAR);
        String yearTODAY = String.valueOf(yearToday);
        
        int weekdaybd = birthday.get(Calendar.DAY_OF_WEEK);
        String weekdayBD =  String.valueOf(weekdaybd);
        int daybd = today.get(Calendar.DAY_OF_MONTH);
        String dayBD =  String.valueOf(daybd);
        int monthbd = today.get(Calendar.MONTH);
        String monthBD =  String.valueOf(monthbd);
        int yearbd = today.get(Calendar.YEAR);
        String yearBD = String.valueOf(yearbd);

        System.out.println(weekdayTODAY+" "+dayTODAY+" "+monthTODAY+" "+yearTODAY);
        System.out.println(weekdayBD+" "+dayBD+" "+monthBD+" "+yearBD);
    }

}
